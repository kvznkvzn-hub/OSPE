# NK Host Bots

Site para hospedagem de bots com painel de usuário, painel admin, planos Free/Ruby/Gold/Diamond, upload ZIP, detecção automática de token e controle via PM2.

## Instalar

```bash
npm install
npm install -g pm2
cp .env.example .env
npm start
```

Abra: http://localhost:3000

## Login admin padrão

E-mail: `admin@nkstore.com`
Senha: `admin123`

Troque isso no arquivo `.env` antes de usar em produção.

## Como o token é encontrado

O sistema procura em:

- `.env`
- `config.json`
- `settings.json`
- `token.txt`
- `index.js`
- `bot.js`
- `src/index.js`

Padrões aceitos:

- `TOKEN=...`
- `DISCORD_TOKEN=...`
- `BOT_TOKEN=...`
- `"token": "..."`
- `client.login("...")`

## Importante

Para usar em hospedagem real, use VPS Linux, Nginx, SSL e Docker para isolar bots de usuários. Esta versão usa PM2 e é uma base inicial funcional.
