require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const AdmZip = require('adm-zip');
const cookieParser = require('cookie-parser');
const sqlite3 = require('sqlite3').verbose();
const { execSync, spawn } = require('child_process');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'troque_essa_chave';
const ROOT = __dirname;
const DB_PATH = path.join(ROOT, 'data', 'database.sqlite');
const UPLOADS = path.join(ROOT, 'uploads');
const BOTS = path.join(ROOT, 'bots');
fs.mkdirSync(path.join(ROOT, 'data'), { recursive: true });
fs.mkdirSync(UPLOADS, { recursive: true });
fs.mkdirSync(BOTS, { recursive: true });

const db = new sqlite3.Database(DB_PATH);
function run(sql, params=[]) { return new Promise((resolve, reject)=>db.run(sql, params, function(err){ err?reject(err):resolve(this); })); }
function get(sql, params=[]) { return new Promise((resolve, reject)=>db.get(sql, params, (err,row)=>err?reject(err):resolve(row))); }
function all(sql, params=[]) { return new Promise((resolve, reject)=>db.all(sql, params, (err,rows)=>err?reject(err):resolve(rows))); }

async function initDb(){
  await run(`CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT, email TEXT UNIQUE, password TEXT, role TEXT DEFAULT 'user', plan TEXT DEFAULT 'Free', active INTEGER DEFAULT 1, created_at TEXT)`);
  await run(`CREATE TABLE IF NOT EXISTS plans (name TEXT PRIMARY KEY, price REAL, max_bots INTEGER, ram TEXT, storage TEXT, upload_mb INTEGER, features TEXT)`);
  await run(`CREATE TABLE IF NOT EXISTS bots (id TEXT PRIMARY KEY, user_id TEXT, name TEXT, folder TEXT, token_mask TEXT, token_found INTEGER, status TEXT DEFAULT 'stopped', main_file TEXT DEFAULT 'index.js', created_at TEXT)`);
  await run(`CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)`);
  const admin = await get('SELECT * FROM users WHERE role="admin"');
  if(!admin){
    const pass = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin123', 10);
    await run('INSERT INTO users VALUES (?,?,?,?,?,?,?,?)', [uuidv4(), process.env.ADMIN_NAME || 'Dono', process.env.ADMIN_EMAIL || 'admin@nkstore.com', pass, 'admin', 'Diamond', 1, new Date().toISOString()]);
  }
  const plans = await all('SELECT * FROM plans');
  if(plans.length===0){
    await run('INSERT INTO plans VALUES (?,?,?,?,?,?,?)', ['Free',0,1,'256 MB','250 MB',20,'1 bot;Console básico;Reinício manual']);
    await run('INSERT INTO plans VALUES (?,?,?,?,?,?,?)', ['Ruby',19.90,3,'512 MB','1 GB',50,'3 bots;Logs completos;Reinício automático']);
    await run('INSERT INTO plans VALUES (?,?,?,?,?,?,?)', ['Gold',39.90,5,'1 GB','3 GB',100,'5 bots;Backup;Mais prioridade']);
    await run('INSERT INTO plans VALUES (?,?,?,?,?,?,?)', ['Diamond',79.90,999,'2 GB+','10 GB+',200,'Bots ilimitados;Prioridade alta;Suporte VIP']);
  }
  const defaults = { siteName:'NK Host Bots', primaryColor:'#2563eb', secondaryColor:'#050816', bannerText:'Deixe seus bots online 24/7', pixKey:'SEU_PIX_AQUI', logoUrl:'', discordUrl:'' };
  for(const [k,v] of Object.entries(defaults)){ if(!await get('SELECT key FROM settings WHERE key=?',[k])) await run('INSERT INTO settings VALUES (?,?)',[k,v]); }
}

const upload = multer({ dest: UPLOADS, limits: { fileSize: 250 * 1024 * 1024 } });
app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use(cookieParser());
app.use('/public', express.static(path.join(ROOT,'public')));
app.set('view engine','ejs');
app.set('views', path.join(ROOT,'views'));

async function settings(){ const rows=await all('SELECT * FROM settings'); return Object.fromEntries(rows.map(r=>[r.key,r.value])); }
function auth(req,res,next){ try{ req.user=jwt.verify(req.cookies.token, JWT_SECRET); next(); } catch{ res.redirect('/login'); } }
function adminOnly(req,res,next){ if(req.user?.role==='admin') return next(); res.status(403).send('Sem permissão'); }
function tokenMask(t){ return t ? '*'.repeat(Math.max(8,t.length-4))+t.slice(-4) : ''; }
function findTokenInFile(filePath){
  const text = fs.readFileSync(filePath,'utf8').slice(0,200000);
  const patterns = [/DISCORD_TOKEN\s*=\s*["']?([^\s"']+)/i,/BOT_TOKEN\s*=\s*["']?([^\s"']+)/i,/TOKEN\s*=\s*["']?([^\s"']+)/i,/token\s*[:=]\s*["']([^"']+)["']/i,/client\.login\(["']([^"']+)["']\)/i];
  for(const p of patterns){ const m=text.match(p); if(m && m[1] && m[1].length>10) return m[1]; }
  return null;
}
function scanToken(dir){
  const names=['.env','config.json','settings.json','token.txt','index.js','bot.js','src/index.js'];
  for(const n of names){ const p=path.join(dir,n); if(fs.existsSync(p) && fs.statSync(p).isFile()){ const t=findTokenInFile(p); if(t) return t; } }
  return null;
}
function findMainFile(dir){ for(const f of ['index.js','bot.js','main.js','src/index.js']) if(fs.existsSync(path.join(dir,f))) return f; return 'index.js'; }
function pm2Name(id){ return `nkbot_${id}`; }
function pm2(cmd){ try{return execSync(cmd,{encoding:'utf8'});}catch(e){return e.stdout?.toString() || e.message;} }

app.get('/', async (req,res)=> res.render('home',{s:await settings(), plans:await all('SELECT * FROM plans')}));
app.get('/login', async (req,res)=>res.render('login',{s:await settings(), error:null}));
app.post('/login', async (req,res)=>{ const u=await get('SELECT * FROM users WHERE email=?',[req.body.email]); if(!u || !await bcrypt.compare(req.body.password,u.password)) return res.render('login',{s:await settings(),error:'Login inválido'}); if(!u.active) return res.render('login',{s:await settings(),error:'Conta desativada'}); res.cookie('token', jwt.sign({id:u.id,email:u.email,role:u.role,name:u.name}, JWT_SECRET), {httpOnly:true}); res.redirect(u.role==='admin'?'/admin':'/dashboard'); });
app.get('/register', async (req,res)=>res.render('register',{s:await settings(), error:null}));
app.post('/register', async (req,res)=>{ try{ const pass=await bcrypt.hash(req.body.password,10); await run('INSERT INTO users VALUES (?,?,?,?,?,?,?,?)',[uuidv4(),req.body.name,req.body.email,pass,'user','Free',1,new Date().toISOString()]); res.redirect('/login'); }catch{ res.render('register',{s:await settings(),error:'E-mail já cadastrado'}); }});
app.get('/logout',(req,res)=>{res.clearCookie('token');res.redirect('/')});

app.get('/dashboard', auth, async (req,res)=>{ const user=await get('SELECT * FROM users WHERE id=?',[req.user.id]); const bots=await all('SELECT * FROM bots WHERE user_id=?',[req.user.id]); const plan=await get('SELECT * FROM plans WHERE name=?',[user.plan]); res.render('dashboard',{s:await settings(), user, bots, plan}); });
app.post('/bots/upload', auth, upload.single('botzip'), async (req,res)=>{ const user=await get('SELECT * FROM users WHERE id=?',[req.user.id]); const plan=await get('SELECT * FROM plans WHERE name=?',[user.plan]); const count=(await all('SELECT * FROM bots WHERE user_id=?',[user.id])).length; if(count>=plan.max_bots) return res.send('Seu plano não permite mais bots.'); const id=uuidv4(); const folder=path.join(BOTS,id); fs.mkdirSync(folder,{recursive:true}); const zip = new AdmZip(req.file.path); zip.extractAllTo(folder,true); fs.unlinkSync(req.file.path); const token=scanToken(folder); await run('INSERT INTO bots VALUES (?,?,?,?,?,?,?,?,?)',[id,user.id,req.body.name||'Meu Bot',folder,tokenMask(token),token?1:0,'stopped',findMainFile(folder),new Date().toISOString()]); res.redirect('/dashboard'); });
app.post('/bots/:id/start', auth, async (req,res)=>{ const bot=await get('SELECT * FROM bots WHERE id=? AND user_id=?',[req.params.id,req.user.id]); if(!bot) return res.status(404).send('Bot não encontrado'); pm2(`cd "${bot.folder}" && pm2 start "${bot.main_file}" --name ${pm2Name(bot.id)} --time`); await run('UPDATE bots SET status="online" WHERE id=?',[bot.id]); res.redirect('/dashboard'); });
app.post('/bots/:id/stop', auth, async (req,res)=>{ const bot=await get('SELECT * FROM bots WHERE id=? AND user_id=?',[req.params.id,req.user.id]); if(bot){ pm2(`pm2 stop ${pm2Name(bot.id)}`); await run('UPDATE bots SET status="stopped" WHERE id=?',[bot.id]); } res.redirect('/dashboard'); });
app.post('/bots/:id/restart', auth, async (req,res)=>{ const bot=await get('SELECT * FROM bots WHERE id=? AND user_id=?',[req.params.id,req.user.id]); if(bot){ pm2(`pm2 restart ${pm2Name(bot.id)}`); await run('UPDATE bots SET status="online" WHERE id=?',[bot.id]); } res.redirect('/dashboard'); });
app.get('/bots/:id/logs', auth, async (req,res)=>{ const bot=await get('SELECT * FROM bots WHERE id=? AND user_id=?',[req.params.id,req.user.id]); if(!bot) return res.status(404).send('Bot não encontrado'); res.type('text/plain').send(pm2(`pm2 logs ${pm2Name(bot.id)} --nostream --lines 80`)); });

app.get('/admin', auth, adminOnly, async (req,res)=> res.render('admin',{s:await settings(), users:await all('SELECT * FROM users ORDER BY created_at DESC'), plans:await all('SELECT * FROM plans'), bots:await all('SELECT bots.*, users.email FROM bots LEFT JOIN users ON users.id=bots.user_id')}));
app.post('/admin/settings', auth, adminOnly, async (req,res)=>{ for(const k of ['siteName','primaryColor','secondaryColor','bannerText','pixKey','logoUrl','discordUrl']) await run('UPDATE settings SET value=? WHERE key=?',[req.body[k]||'',k]); res.redirect('/admin'); });
app.post('/admin/user/:id', auth, adminOnly, async (req,res)=>{ await run('UPDATE users SET plan=?, active=? WHERE id=?',[req.body.plan, req.body.active?1:0, req.params.id]); res.redirect('/admin'); });
app.post('/admin/plans/:name', auth, adminOnly, async (req,res)=>{ await run('UPDATE plans SET price=?, max_bots=?, ram=?, storage=?, upload_mb=?, features=? WHERE name=?',[req.body.price,req.body.max_bots,req.body.ram,req.body.storage,req.body.upload_mb,req.body.features,req.params.name]); res.redirect('/admin'); });

initDb().then(()=>app.listen(PORT,()=>console.log(`NK Host Bots em http://localhost:${PORT}`)));
